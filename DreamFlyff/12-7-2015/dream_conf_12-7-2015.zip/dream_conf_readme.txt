----------------- offical dream flyff conf -----------------

>>>>>>>>>>>>>> place this file wheres pylaf.py <<<<<<<<<<<<<<

* - range: maximizes your attack range
* - spam skill: presses skills for you. you can add them more in config file.
	and you can select with mouse how many you want them to be active,
	and then finally click on or off
* - auto select target: gathers all moving objects around you and start
        selecting them.